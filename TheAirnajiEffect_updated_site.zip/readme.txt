NOWGRAPHY — TheAirnajiEffect

Netlify-ready static website.
Upload this folder to Netlify Drop or deploy it as a static site.
